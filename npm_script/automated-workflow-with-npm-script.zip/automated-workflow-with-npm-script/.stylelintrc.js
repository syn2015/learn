module.exports = {
  "extends": "stylelint-config-standard",
  "rules": {
    "at-rule-empty-line-before": null
  }
};

