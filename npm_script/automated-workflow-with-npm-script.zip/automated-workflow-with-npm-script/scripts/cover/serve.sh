#!/usr/bin/env bash

http-server coverage_archive/$npm_package_version -p $npm_package_config_port

