#!/usr/bin/env bash

sleep 1
opn http://localhost:$npm_package_config_port

