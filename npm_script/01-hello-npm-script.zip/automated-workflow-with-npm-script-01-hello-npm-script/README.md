# 用 npm script 打造超溜的前端工作流

> step-by-step 讲解如何使用 npm script 打造自动化的前端工作流，完整版见[掘金小册](https://juejin.im/book/5a1212bc51882531ea64df07)，这里是每个章节的代码。

