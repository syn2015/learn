const str = 'some value';

function fn(){
  console.log('some log');
}
