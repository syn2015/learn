import  './a'
import  './b'

console.log('other.js')