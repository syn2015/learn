
// module.exports = 'hankewudi'
function sum(a,b) {
  return a+b
}

function mins(a,b) {
  return a-b
}

export default {sum,mins}