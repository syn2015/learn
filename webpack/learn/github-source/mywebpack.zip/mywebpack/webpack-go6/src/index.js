// console.log('hello')

//inline-loader! 这样会运行inline-loader
// -!不会通过 pre normal来处理了
// !没有normal
// !!什么都不要  只用inline-loader
// require('inline-loader!./a.js')

/* class Hanke{
  constructor(){
    this.name = 'hanke'
  }
  getName(){
    return this.name
  }
}
var h = new Hanke()
console.log(h.getName()) */

/* import p from './lala.jpg'
console.log(p)
let img = document.createElement('img')
img.src = p
document.body.appendChild(img) */

require('./index.less')