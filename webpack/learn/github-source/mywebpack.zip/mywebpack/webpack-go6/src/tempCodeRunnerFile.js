
import p from './lala.jpg'
console.log(p)