let a = 3,b = 4
[b, a] = [a, b]
console.log(b)